cd app1
cp ../core.yaml .
go build

cd ../app2
cp ../core.yaml .
go build

cd ../app3
cp ../core.yaml .
go build

cd ..
